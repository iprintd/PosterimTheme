import './Cart.scss'
import urlGenerator from '$ustoreinternal/services/urlGenerator'
import {Link} from '$routes'
import Icon from '$core-components/Icon'

/**
 * This component represents the cart icon.
 * When clicking on it - the store redirects to the 'Cart' page
 */
const cart_icon =  require(`$assets/images/cart.png`)
const Cart = () => {
	return(
	  <div className="cart">
      <Link to={urlGenerator.get({page:'cart'})}>
        <a>
          <div className="cart-icon-container">
          {cart_icon && <img src={cart_icon} alt="Cart" />}
          </div>
        </a>
      </Link>
    </div>
	)
}
export default Cart
